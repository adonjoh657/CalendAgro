using System.Collections.ObjectModel;
using CalendAgro.Models;
using CalendAgro.Resources.Strings;
using CalendAgro.Services;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace CalendAgro.ViewModels;

// Catalogue : recherche directe, filtre par saison, états.
public sealed partial class CulturesViewModel : ObservableObject
{
    private readonly ICultureService _cultures;
    private readonly ITabNavigationService _tabs;
    private bool _started;

    public ObservableCollection<Culture> Resultats { get; } = [];

    public IReadOnlyList<string> Saisons { get; } =
    [
        AppResources.Cultures_ToutesSaisons,
        AppResources.Fiche_SaisonGrandeSeche,
        AppResources.Fiche_SaisonPetitePluies,
        AppResources.Fiche_SaisonPetiteSeche,
        AppResources.Fiche_SaisonGrandePluies,
    ];

    [ObservableProperty]
    public partial string Recherche { get; set; } = string.Empty;

    [ObservableProperty]
    public partial string SaisonChoisie { get; set; } = string.Empty;

    [ObservableProperty]
    public partial string NbResultats { get; set; } = string.Empty;

    [ObservableProperty]
    public partial bool IsBusy { get; set; } = true;

    [ObservableProperty]
    public partial bool HasError { get; set; }

    [ObservableProperty]
    public partial string NavigationErreur { get; set; } = string.Empty;

    public bool IsListeVisible => !IsBusy && !HasError;

    public bool NavigationErreurVisible => NavigationErreur.Length > 0;

    // Catalogue de référence vide (aucune recherche, filtre par défaut)
    // ou aucun résultat pour la recherche en cours.
    public bool CatalogueVide =>
        Resultats.Count == 0
        && Recherche.Length == 0
        && SaisonChoisie == AppResources.Cultures_ToutesSaisons;

    public string MessageVide =>
        CatalogueVide ? AppResources.Cultures_Aucune : AppResources.Cultures_AucunResultat;

    public string ActionVide => CatalogueVide ? string.Empty : AppResources.Cultures_Effacer;

    public bool NbResultatsVisible => Resultats.Count > 0;

    public CulturesViewModel(ICultureService cultures, ITabNavigationService tabs)
    {
        _cultures = cultures;
        _tabs = tabs;
        SaisonChoisie = AppResources.Cultures_ToutesSaisons;
    }

    // Repli hors DI (Shell DataTemplate = constructeur sans paramètre).
    public CulturesViewModel() : this(DefaultServices.Cultures, DefaultServices.Navigation)
    {
    }

    partial void OnRechercheChanged(string value) => _ = FiltrerAsync();

    partial void OnSaisonChoisieChanged(string value) => _ = FiltrerAsync();

    partial void OnIsBusyChanged(bool value) => OnPropertyChanged(nameof(IsListeVisible));

    partial void OnHasErrorChanged(bool value) => OnPropertyChanged(nameof(IsListeVisible));

    partial void OnNavigationErreurChanged(string value) => OnPropertyChanged(nameof(NavigationErreurVisible));

    public async Task LoadAsync()
    {
        if (_started)
        {
            return;
        }
        _started = true;
        await RechargerAsync();
    }

    [RelayCommand]
    private async Task RechargerAsync()
    {
        IsBusy = true;
        HasError = false;
        try
        {
            await FiltrerAsync();
        }
        finally
        {
            IsBusy = false;
        }
    }

    [RelayCommand]
    private void EffacerRecherche()
    {
        Recherche = string.Empty;
        SaisonChoisie = AppResources.Cultures_ToutesSaisons;
    }

    [RelayCommand]
    private async Task OuvrirFicheAsync(string cultureId)
    {
        try
        {
            await Shell.Current.GoToAsync($"fiche-culture?cultureId={cultureId}");
        }
        catch
        {
            NavigationErreur = AppResources.Cultures_FicheEnCours;
        }
    }

    [RelayCommand]
    private Task GoNext() => _tabs.GoNextAsync();

    [RelayCommand]
    private Task GoPrevious() => _tabs.GoPreviousAsync();

    private async Task FiltrerAsync()
    {
        try
        {
            NavigationErreur = string.Empty;
            var cultures = await _cultures.SearchAsync(Recherche, SaisonDe(SaisonChoisie));
            Resultats.Clear();
            foreach (var culture in cultures)
            {
                Resultats.Add(culture);
            }
            NbResultats = string.Format(AppResources.Cultures_NbDisponibles, Resultats.Count);
            NotifierEtatsVides();
        }
        catch
        {
            HasError = true;
        }
    }

    private void NotifierEtatsVides()
    {
        OnPropertyChanged(nameof(CatalogueVide));
        OnPropertyChanged(nameof(MessageVide));
        OnPropertyChanged(nameof(ActionVide));
        OnPropertyChanged(nameof(NbResultatsVisible));
    }

    private static string? SaisonDe(string libelle) =>
        libelle == AppResources.Cultures_ToutesSaisons ? null : libelle;
}
