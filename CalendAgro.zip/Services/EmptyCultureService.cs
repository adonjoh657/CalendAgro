using CalendAgro.Models;
using CalendAgro.Resources.Strings;

namespace CalendAgro.Services;

// Référentiel des cultures : vide tant que les données validées (IRAD, MINADER)
// ne sont pas embarquées dans Resources/Raw (PLAN 20). Seules les zones et les
// saisons du cahier des charges sont fournies : ce sont des repères fixes,
// pas des données agricoles inventées.
public sealed class EmptyCultureService : ICultureService
{
    private static readonly string[] Zones =
    [
        AppResources.Fiche_ZoneLittoral,
        AppResources.Fiche_ZoneCentre,
        AppResources.Fiche_ZoneOuest,
        AppResources.Fiche_ZoneExtremeNord,
    ];

    private static readonly string[] Saisons =
    [
        AppResources.Fiche_SaisonGrandeSeche,
        AppResources.Fiche_SaisonPetitePluies,
        AppResources.Fiche_SaisonPetiteSeche,
        AppResources.Fiche_SaisonGrandePluies,
    ];

    public Task<IReadOnlyList<Culture>> GetCulturesAsync() =>
        Task.FromResult<IReadOnlyList<Culture>>([]);

    public Task<IReadOnlyList<Culture>> SearchAsync(string? texte, string? saison) =>
        Task.FromResult<IReadOnlyList<Culture>>([]);

    public Task<Culture?> GetCultureAsync(string cultureId) =>
        Task.FromResult<Culture?>(null);

    public Task<IReadOnlyList<string>> GetZonesAsync() =>
        Task.FromResult<IReadOnlyList<string>>(Zones);

    public Task<IReadOnlyList<string>> GetSaisonsAsync() =>
        Task.FromResult<IReadOnlyList<string>>(Saisons);

    public Task<IReadOnlyList<Etape>> GetEtapesAsync(string cultureId, string zone, string saison) =>
        Task.FromResult<IReadOnlyList<Etape>>([]);

    public Task<IReadOnlyList<Conseil>> GetConseilsAsync(string cultureId) =>
        Task.FromResult<IReadOnlyList<Conseil>>([]);
}
