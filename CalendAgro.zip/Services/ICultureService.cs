using CalendAgro.Models;

namespace CalendAgro.Services;

// Données de référence : cultures, recherche insensible aux accents,
// filtre par saison. JSON embarqué plus tard ; factice pour la phase B.
public interface ICultureService
{
    Task<IReadOnlyList<Culture>> GetCulturesAsync();

    Task<IReadOnlyList<Culture>> SearchAsync(string? texte, string? saison);

    Task<Culture?> GetCultureAsync(string cultureId);

    Task<IReadOnlyList<string>> GetZonesAsync();

    Task<IReadOnlyList<string>> GetSaisonsAsync();

    Task<IReadOnlyList<Etape>> GetEtapesAsync(string cultureId, string zone, string saison);

    Task<IReadOnlyList<Conseil>> GetConseilsAsync(string cultureId);
}
