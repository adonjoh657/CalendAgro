using CalendAgro.Models;
using CalendAgro.Resources.Strings;

namespace CalendAgro.Services;

// Dates des phases d'une parcelle : ancrées sur la date de semis saisie, avec les
// écarts entre phases tirés des étapes de référence (culture + zone + saison).
// Données d'exemple, non officielles : la logique suit le JSON, elle ne l'invente pas.
public sealed class CalendrierService : ICalendrierService
{
    private readonly ICultureService _cultures;

    public CalendrierService(ICultureService cultures) => _cultures = cultures;

    public async Task<IReadOnlyList<Travail>> GetTravauxAsync(
        Parcelle parcelle,
        IReadOnlySet<TypeEtape> phasesTerminees)
    {
        var dates = await GetDatesAsync(parcelle).ConfigureAwait(false);
        var aujourdHui = DateOnly.FromDateTime(DateTime.Today);

        return dates
            .Where(p => p.Value >= aujourdHui && !phasesTerminees.Contains(p.Key))
            .OrderBy(p => p.Value)
            .ThenBy(p => Ordre(p.Key))
            .Select(p => CreerTravail(parcelle, p.Key, p.Value))
            .ToArray();
    }

    public async Task<DateOnly?> GetDatePhaseAsync(Parcelle parcelle, TypeEtape phase)
    {
        var dates = await GetDatesAsync(parcelle).ConfigureAwait(false);
        return dates.TryGetValue(phase, out var date) ? date : null;
    }

    internal static string TitreDe(TypeEtape phase) => phase switch
    {
        TypeEtape.Semis => AppResources.Travail_Semis,
        TypeEtape.Recolte => AppResources.Travail_Recolte,
        _ => AppResources.Travail_Entretien,
    };

    internal static string AccrocheDe(TypeEtape phase) => phase switch
    {
        TypeEtape.Semis => AppResources.Travail_SemisAccroche,
        TypeEtape.Recolte => AppResources.Travail_RecolteAccroche,
        _ => AppResources.Travail_EntretienAccroche,
    };

    // Première date de chaque phase, en prenant la plus proche selon la saison.
    private async Task<Dictionary<TypeEtape, DateOnly>> GetDatesAsync(Parcelle parcelle)
    {
        var dates = new Dictionary<TypeEtape, DateOnly>();
        foreach (var saison in await _cultures.GetSaisonsAsync().ConfigureAwait(false))
        {
            var etapes = await _cultures
                .GetEtapesAsync(parcelle.CultureId, parcelle.Region, saison)
                .ConfigureAwait(false);
            var semis = etapes.FirstOrDefault(e => e.Type == TypeEtape.Semis);
            if (semis is null)
            {
                continue;
            }

            foreach (var etape in etapes)
            {
                var date = parcelle.DateSemis.AddMonths(EcartMois(semis.MoisDebut, etape.MoisDebut));
                if (!dates.TryGetValue(etape.Type, out var existante) || date < existante)
                {
                    dates[etape.Type] = date;
                }
            }
        }

        return dates;
    }

    private static Travail CreerTravail(Parcelle parcelle, TypeEtape phase, DateOnly date) => new()
    {
        Id = TravailId.Creer(parcelle.Id, phase),
        Titre = TitreDe(phase),
        ParcelleNom = parcelle.Nom,
        CultureNom = parcelle.CultureNom,
        Date = date,
        Phase = phase,
    };

    private static int EcartMois(int moisReference, int mois) => ((mois - moisReference) + 12) % 12;

    private static int Ordre(TypeEtape phase) => phase switch
    {
        TypeEtape.Semis => 0,
        TypeEtape.Entretien => 1,
        _ => 2,
    };
}
